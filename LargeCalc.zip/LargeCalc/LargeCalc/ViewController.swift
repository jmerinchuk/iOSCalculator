/************************************************************
 * Program: Large Calculator
 * Programmer: Jayce Merinchuk
 * Date: July 30th, 2019
 * Description: Basic Calculator App which functions
 *      on all iOS devices.
 ***********************************************************/

// Imports
import UIKit

/***********************************************************
 * Method: ViewController: UIViewController Class
 * Description: Main Class for the single view app.
 **********************************************************/
class ViewController: UIViewController {
    
    // Class Variables
    var currentOperator: String = ""
    var currentNumber: String = ""
    var storedNumber: String = ""

    // Outlets for all Labels on screen
    @IBOutlet weak var lblDisplay: UILabel!
    @IBOutlet weak var lblRunTotLBL: UILabel!
    @IBOutlet weak var lblRunningTotalBox: UILabel!
    @IBOutlet weak var lblCurrentOperator: UILabel!
    
    /*******************************************************
     * Method: viewDidLoad()
     * Description: Initial function when program loads.
    *******************************************************/
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    /*******************************************************
     * Method: didReceiveMemoryWarning()
     * Description: Checks for memory issues.
     *******************************************************/
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    /*******************************************************
     * Method: updateScreen()
     * Description: Updates screen with current values
     *******************************************************/
    func updateScreen() {
        lblDisplay.text = String(currentNumber)
        lblRunningTotalBox.text = String(storedNumber)
    }

    /*******************************************************
     * Method: btn0
     * Description: Contains logic for button 0
     *******************************************************/
    @IBAction func btn0(_ sender: Any) {
        if !(currentNumber == "0") {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "0"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn1
     * Description: Contains logic for button 1
     *******************************************************/
    @IBAction func btn1(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "1"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "1"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn2
     * Description: Contains logic for button 2
     *******************************************************/
    @IBAction func btn2(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "2"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "2"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn3
     * Description: Contains logic for button 3
     *******************************************************/
    @IBAction func btn3(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "3"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "3"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn4
     * Description: Contains logic for button 4
     *******************************************************/
    @IBAction func btn4(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "4"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "4"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn5
     * Description: Contains logic for button 5
     *******************************************************/
    @IBAction func btn5(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "5"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "5"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn6
     * Description: Contains logic for button 6
     *******************************************************/
    @IBAction func btn6(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "6"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "6"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn7
     * Description: Contains logic for button 7
     *******************************************************/
    @IBAction func btn7(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "7"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "7"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn8
     * Description: Contains logic for button 8
     *******************************************************/
    @IBAction func btn8(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "8"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "8"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btn9
     * Description: Contains logic for button 9
     *******************************************************/
    @IBAction func btn9(_ sender: Any) {
        if (currentNumber == "0") {
            currentNumber = "9"
        } else {
            if (currentNumber.count < 9) {
                currentNumber = currentNumber + "9"
            }
        }
        updateScreen()
    }
    
    /*******************************************************
     * Method: btnAdd
     * Description: Contains logic for Add button
     *******************************************************/
    @IBAction func btnAdd(_ sender: Any) {
        currentOperator = "+"
        storedNumber = currentNumber
        currentNumber = ""
        
        updateScreen()
    }
    
    /*******************************************************
     * Method: btnSubtract
     * Description: Contains logic for Subtract button
     *******************************************************/
    @IBAction func btnSubtract(_ sender: Any) {
        currentOperator = "-"
        storedNumber = currentNumber
        currentNumber = ""
        
        updateScreen()
    }
    
    /*******************************************************
     * Method: btnMultiply
     * Description: Contains logic for Multiply button
     *******************************************************/
    @IBAction func btnMultiply(_ sender: Any) {
        currentOperator = "*"
        storedNumber = currentNumber
        currentNumber = ""

        updateScreen()
    }
    
    /*******************************************************
     * Method: btnDivide
     * Description: Contains logic for Divide button
     *******************************************************/
    @IBAction func btnDivide(_ sender: Any) {
        currentOperator = "/"
        storedNumber = currentNumber
        currentNumber = ""
        
        updateScreen()
    }
    
    /*******************************************************
     * Method: btnClear
     * Description: Clear all variables and update screen
     *******************************************************/
    @IBAction func btnClear(_ sender: Any) {
        currentOperator = ""
        currentNumber = ""
        storedNumber = ""
        updateScreen()
    }
    
    /*******************************************************
     * Method: btnEquals
     * Description: Contains logic for Equals button
     *******************************************************/
    @IBAction func btnEquals(_ sender: Any) {
        
        // If Display box or Running Total Box are Empty
        if !(currentNumber == "" || storedNumber == "") {
            let number1 = Double(storedNumber);
            let number2 = Double(currentNumber);
            var result: Double = 0
            
            // If statement for if Add is current operator
            if (currentOperator == "+") {
                result = Double(number1! + number2!);
            }
            
            // If statement for if Subtract is current operator
            if (currentOperator == "-") {
                result = Double(number1! - number2!);
            }
            
            // If statement for if Multiply is current operator
            if (currentOperator == "*") {
                result = Double(number1! * number2!);
            }
            
            // If statement for if Divide is current operator
            if (currentOperator == "/") {
                // If statement to ensure we don't divide by 0
                if (number2 == 0) {
                    currentNumber = String("0");
                }
                else {
                    result = Double(number1! / number2!);
                }
            }
            currentNumber = String(result);
        }
        updateScreen()
    }
}
